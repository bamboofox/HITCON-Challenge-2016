|You found the passcode for the bomb is encrypted|
|by Advanced Encryption Stantard(AES),           |
|and the decryption password is encrypted by RSA.|
|Now, try to decrypt the passcode before the bomb|
|explode!                                        |

Hint:
1.Use yafu to factor N into p & q.(https://sourceforge.net/projects/yafu)
2.Use rsatools to get the RSA private key.(http://eggdrop.ch/projects/rsatools/index_en.htm)
3.Use openssl to decrypt the decryption password of AES.
